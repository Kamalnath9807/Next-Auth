"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/protected";
exports.ids = ["pages/protected"];
exports.modules = {

/***/ "./pages/protected.tsx":
/*!*****************************!*\
  !*** ./pages/protected.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);\n\n\n\n\nconst Protected = ()=>{\n    const { status , data  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.useSession)();\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        if (status === \"unauthenticated\") next_router__WEBPACK_IMPORTED_MODULE_3___default().replace(\"/auth/signin\");\n    }, [\n        status\n    ]);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            \"This page is Protected for special people. like\",\n            \"\\n\",\n            JSON.stringify(data?.user, null, 2)\n        ]\n    }, void 0, true, {\n        fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/protected.tsx\",\n        lineNumber: 13,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Protected);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9wcm90ZWN0ZWQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBO0FBQzZDO0FBQ1g7QUFDRDtBQUVqQyxNQUFNRyxZQUFzQixJQUFtQjtJQUM3QyxNQUFNLEVBQUVDLE9BQU0sRUFBRUMsS0FBSSxFQUFFLEdBQUdMLDJEQUFVQTtJQUVuQ0MsZ0RBQVNBLENBQUMsSUFBTTtRQUNkLElBQUlHLFdBQVcsbUJBQW1CRiwwREFBYyxDQUFDO0lBQ25ELEdBQUc7UUFBQ0U7S0FBTztJQUNYLHFCQUNFLDhEQUFDRzs7WUFBSTtZQUM2QztZQUMvQ0MsS0FBS0MsU0FBUyxDQUFDSixNQUFNSyxNQUFNLElBQUksRUFBRTs7Ozs7OztBQUd4QztBQUVBLGlFQUFlUCxTQUFTQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnVsbC1zdGFjay1uaXJhai8uL3BhZ2VzL3Byb3RlY3RlZC50c3g/MjcwYyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZXh0UGFnZSB9IGZyb20gJ25leHQnO1xuaW1wb3J0IHsgdXNlU2Vzc2lvbiB9IGZyb20gJ25leHQtYXV0aC9yZWFjdCc7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJztcblxuY29uc3QgUHJvdGVjdGVkOiBOZXh0UGFnZSA9ICgpOiBKU1guRWxlbWVudCA9PiB7XG4gIGNvbnN0IHsgc3RhdHVzLCBkYXRhIH0gPSB1c2VTZXNzaW9uKCk7XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoc3RhdHVzID09PSAndW5hdXRoZW50aWNhdGVkJykgUm91dGVyLnJlcGxhY2UoJy9hdXRoL3NpZ25pbicpO1xuICB9LCBbc3RhdHVzXSk7XG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIFRoaXMgcGFnZSBpcyBQcm90ZWN0ZWQgZm9yIHNwZWNpYWwgcGVvcGxlLiBsaWtleydcXG4nfVxuICAgICAge0pTT04uc3RyaW5naWZ5KGRhdGE/LnVzZXIsIG51bGwsIDIpfVxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgUHJvdGVjdGVkO1xuIl0sIm5hbWVzIjpbInVzZVNlc3Npb24iLCJ1c2VFZmZlY3QiLCJSb3V0ZXIiLCJQcm90ZWN0ZWQiLCJzdGF0dXMiLCJkYXRhIiwicmVwbGFjZSIsImRpdiIsIkpTT04iLCJzdHJpbmdpZnkiLCJ1c2VyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/protected.tsx\n");

/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/protected.tsx"));
module.exports = __webpack_exports__;

})();