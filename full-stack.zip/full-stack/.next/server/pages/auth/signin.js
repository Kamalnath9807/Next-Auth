"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/auth/signin";
exports.ids = ["pages/auth/signin"];
exports.modules = {

/***/ "./pages/auth/signin.tsx":
/*!*******************************!*\
  !*** ./pages/auth/signin.tsx ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst SignIn = (props)=>{\n    const [userInfo, setUserInfo] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({\n        email: \"\",\n        password: \"\"\n    });\n    const handleSubmit = async (e)=>{\n        // validate userInfo\n        e.preventDefault();\n        const res = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.signIn)(\"credentials\", {\n            email: userInfo.email,\n            password: userInfo.password,\n            redirect: false\n        });\n    };\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        className: \"sign-in-form\",\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"form\", {\n            onSubmit: handleSubmit,\n            children: [\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"h1\", {\n                    children: \"Login\"\n                }, void 0, false, {\n                    fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/auth/signin.tsx\",\n                    lineNumber: 24,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                    value: userInfo.email,\n                    onChange: ({ target  })=>setUserInfo({\n                            ...userInfo,\n                            email: target.value\n                        }),\n                    type: \"email\",\n                    placeholder: \"john@email.com\"\n                }, void 0, false, {\n                    fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/auth/signin.tsx\",\n                    lineNumber: 25,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                    value: userInfo.password,\n                    onChange: ({ target  })=>setUserInfo({\n                            ...userInfo,\n                            password: target.value\n                        }),\n                    type: \"password\",\n                    placeholder: \"*********\"\n                }, void 0, false, {\n                    fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/auth/signin.tsx\",\n                    lineNumber: 33,\n                    columnNumber: 9\n                }, undefined),\n                /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                    type: \"submit\",\n                    value: \"Login\"\n                }, void 0, false, {\n                    fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/auth/signin.tsx\",\n                    lineNumber: 41,\n                    columnNumber: 9\n                }, undefined)\n            ]\n        }, void 0, true, {\n            fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/auth/signin.tsx\",\n            lineNumber: 23,\n            columnNumber: 7\n        }, undefined)\n    }, void 0, false, {\n        fileName: \"/home/kamalnath/Documents/nextjsAuth/NextAuthSign/full-stack-niraj/pages/auth/signin.tsx\",\n        lineNumber: 22,\n        columnNumber: 5\n    }, undefined);\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SignIn);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9hdXRoL3NpZ25pbi50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQ3lDO0FBQ1U7QUFLbkQsTUFBTUUsU0FBbUIsQ0FBQ0MsUUFBdUI7SUFDL0MsTUFBTSxDQUFDQyxVQUFVQyxZQUFZLEdBQUdKLCtDQUFRQSxDQUFDO1FBQUVLLE9BQU87UUFBSUMsVUFBVTtJQUFHO0lBQ25FLE1BQU1DLGVBQWtELE9BQU9DLElBQU07UUFDbkUsb0JBQW9CO1FBQ3BCQSxFQUFFQyxjQUFjO1FBRWhCLE1BQU1DLE1BQU0sTUFBTVgsdURBQU1BLENBQUMsZUFBZTtZQUN0Q00sT0FBT0YsU0FBU0UsS0FBSztZQUNyQkMsVUFBVUgsU0FBU0csUUFBUTtZQUMzQkssVUFBVSxLQUFLO1FBQ2pCO0lBQ0Y7SUFFQSxxQkFDRSw4REFBQ0M7UUFBSUMsV0FBVTtrQkFDYiw0RUFBQ0M7WUFBS0MsVUFBVVI7OzhCQUNkLDhEQUFDUzs4QkFBRzs7Ozs7OzhCQUNKLDhEQUFDQztvQkFDQ0MsT0FBT2YsU0FBU0UsS0FBSztvQkFDckJjLFVBQVUsQ0FBQyxFQUFFQyxPQUFNLEVBQUUsR0FDbkJoQixZQUFZOzRCQUFFLEdBQUdELFFBQVE7NEJBQUVFLE9BQU9lLE9BQU9GLEtBQUs7d0JBQUM7b0JBRWpERyxNQUFLO29CQUNMQyxhQUFZOzs7Ozs7OEJBRWQsOERBQUNMO29CQUNDQyxPQUFPZixTQUFTRyxRQUFRO29CQUN4QmEsVUFBVSxDQUFDLEVBQUVDLE9BQU0sRUFBRSxHQUNuQmhCLFlBQVk7NEJBQUUsR0FBR0QsUUFBUTs0QkFBRUcsVUFBVWMsT0FBT0YsS0FBSzt3QkFBQztvQkFFcERHLE1BQUs7b0JBQ0xDLGFBQVk7Ozs7Ozs4QkFFZCw4REFBQ0w7b0JBQU1JLE1BQUs7b0JBQVNILE9BQU07Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSW5DO0FBRUEsaUVBQWVqQixNQUFNQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnVsbC1zdGFjay1uaXJhai8uL3BhZ2VzL2F1dGgvc2lnbmluLnRzeD9lNzY2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5leHRQYWdlIH0gZnJvbSAnbmV4dCc7XG5pbXBvcnQgeyBzaWduSW4gfSBmcm9tICduZXh0LWF1dGgvcmVhY3QnO1xuaW1wb3J0IHsgRm9ybUV2ZW50SGFuZGxlciwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgSlNYU3R5bGUgZnJvbSAnc3R5bGVkLWpzeC9zdHlsZSc7XG5cbmludGVyZmFjZSBQcm9wcyB7fVxuXG5jb25zdCBTaWduSW46IE5leHRQYWdlID0gKHByb3BzKTogSlNYLkVsZW1lbnQgPT4ge1xuICBjb25zdCBbdXNlckluZm8sIHNldFVzZXJJbmZvXSA9IHVzZVN0YXRlKHsgZW1haWw6ICcnLCBwYXNzd29yZDogJycgfSk7XG4gIGNvbnN0IGhhbmRsZVN1Ym1pdDogRm9ybUV2ZW50SGFuZGxlcjxIVE1MRm9ybUVsZW1lbnQ+ID0gYXN5bmMgKGUpID0+IHtcbiAgICAvLyB2YWxpZGF0ZSB1c2VySW5mb1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHNpZ25JbignY3JlZGVudGlhbHMnLCB7XG4gICAgICBlbWFpbDogdXNlckluZm8uZW1haWwsXG4gICAgICBwYXNzd29yZDogdXNlckluZm8ucGFzc3dvcmQsXG4gICAgICByZWRpcmVjdDogZmFsc2UsXG4gICAgfSk7XG4gIH07XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT0nc2lnbi1pbi1mb3JtJz5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgICA8aDE+TG9naW48L2gxPlxuICAgICAgICA8aW5wdXRcbiAgICAgICAgICB2YWx1ZT17dXNlckluZm8uZW1haWx9XG4gICAgICAgICAgb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PlxuICAgICAgICAgICAgc2V0VXNlckluZm8oeyAuLi51c2VySW5mbywgZW1haWw6IHRhcmdldC52YWx1ZSB9KVxuICAgICAgICAgIH1cbiAgICAgICAgICB0eXBlPSdlbWFpbCdcbiAgICAgICAgICBwbGFjZWhvbGRlcj0nam9obkBlbWFpbC5jb20nXG4gICAgICAgIC8+XG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHZhbHVlPXt1c2VySW5mby5wYXNzd29yZH1cbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+XG4gICAgICAgICAgICBzZXRVc2VySW5mbyh7IC4uLnVzZXJJbmZvLCBwYXNzd29yZDogdGFyZ2V0LnZhbHVlIH0pXG4gICAgICAgICAgfVxuICAgICAgICAgIHR5cGU9J3Bhc3N3b3JkJ1xuICAgICAgICAgIHBsYWNlaG9sZGVyPScqKioqKioqKionXG4gICAgICAgIC8+XG4gICAgICAgIDxpbnB1dCB0eXBlPSdzdWJtaXQnIHZhbHVlPSdMb2dpbicgLz5cbiAgICAgIDwvZm9ybT5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFNpZ25JbjtcbiJdLCJuYW1lcyI6WyJzaWduSW4iLCJ1c2VTdGF0ZSIsIlNpZ25JbiIsInByb3BzIiwidXNlckluZm8iLCJzZXRVc2VySW5mbyIsImVtYWlsIiwicGFzc3dvcmQiLCJoYW5kbGVTdWJtaXQiLCJlIiwicHJldmVudERlZmF1bHQiLCJyZXMiLCJyZWRpcmVjdCIsImRpdiIsImNsYXNzTmFtZSIsImZvcm0iLCJvblN1Ym1pdCIsImgxIiwiaW5wdXQiLCJ2YWx1ZSIsIm9uQ2hhbmdlIiwidGFyZ2V0IiwidHlwZSIsInBsYWNlaG9sZGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/auth/signin.tsx\n");

/***/ }),

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/auth/signin.tsx"));
module.exports = __webpack_exports__;

})();