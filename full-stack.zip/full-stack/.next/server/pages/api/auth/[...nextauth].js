"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/auth/[...nextauth]";
exports.ids = ["pages/api/auth/[...nextauth]"];
exports.modules = {

/***/ "next-auth":
/*!****************************!*\
  !*** external "next-auth" ***!
  \****************************/
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ "next-auth/providers/credentials":
/*!**************************************************!*\
  !*** external "next-auth/providers/credentials" ***!
  \**************************************************/
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ "(api)/./pages/api/auth/[...nextauth].ts":
/*!*****************************************!*\
  !*** ./pages/api/auth/[...nextauth].ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth */ \"next-auth\");\n/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next-auth/providers/credentials */ \"next-auth/providers/credentials\");\n/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst authOptions = {\n    session: {\n        strategy: \"jwt\"\n    },\n    providers: [\n        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_1___default()({\n            type: \"credentials\",\n            credentials: {},\n            authorize (credentials, req) {\n                const { email , password  } = credentials;\n                // performing login logic\n                // finding user from db\n                if (email === \"john@gmail.com\" && password !== \"1234\") {\n                    throw new Error(\"invalid credentials\");\n                }\n                //if everything is fine\n                return {\n                    id: \"1234\",\n                    name: \"john Doe\",\n                    email: \"john@gmail.com\"\n                };\n            }\n        })\n    ],\n    pages: {\n        signIn: \"/auth/signin\"\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (next_auth__WEBPACK_IMPORTED_MODULE_0___default()(authOptions));\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYXV0aC9bLi4ubmV4dGF1dGhdLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQWlDO0FBRWlDO0FBRWxFLE1BQU1FLGNBQStCO0lBQ25DQyxTQUFTO1FBQ1BDLFVBQVU7SUFDWjtJQUNBQyxXQUFXO1FBQ1RKLHNFQUFtQkEsQ0FBQztZQUNsQkssTUFBTTtZQUNOQyxhQUFhLENBQUM7WUFDZEMsV0FBVUQsV0FBVyxFQUFFRSxHQUFHLEVBQUU7Z0JBQzFCLE1BQU0sRUFBRUMsTUFBSyxFQUFFQyxTQUFRLEVBQUUsR0FBR0o7Z0JBSTVCLHlCQUF5QjtnQkFDekIsdUJBQXVCO2dCQUN2QixJQUFJRyxVQUFVLG9CQUFvQkMsYUFBYSxRQUFRO29CQUNyRCxNQUFNLElBQUlDLE1BQU0sdUJBQXVCO2dCQUN6QyxDQUFDO2dCQUNELHVCQUF1QjtnQkFDdkIsT0FBTztvQkFBRUMsSUFBSTtvQkFBUUMsTUFBTTtvQkFBWUosT0FBTztnQkFBaUI7WUFDakU7UUFDRjtLQUNEO0lBQ0RLLE9BQU87UUFDTEMsUUFBUTtJQUdWO0FBQ0Y7QUFFQSxpRUFBZWhCLGdEQUFRQSxDQUFDRSxZQUFZQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnVsbC1zdGFjay1uaXJhai8uL3BhZ2VzL2FwaS9hdXRoL1suLi5uZXh0YXV0aF0udHM/MmU4YiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTmV4dEF1dGggZnJvbSAnbmV4dC1hdXRoJztcbmltcG9ydCB7IE5leHRBdXRoT3B0aW9ucyB9IGZyb20gJ25leHQtYXV0aCc7XG5pbXBvcnQgQ3JlZGVudGlhbHNQcm92aWRlciBmcm9tICduZXh0LWF1dGgvcHJvdmlkZXJzL2NyZWRlbnRpYWxzJztcblxuY29uc3QgYXV0aE9wdGlvbnM6IE5leHRBdXRoT3B0aW9ucyA9IHtcbiAgc2Vzc2lvbjoge1xuICAgIHN0cmF0ZWd5OiAnand0JyxcbiAgfSxcbiAgcHJvdmlkZXJzOiBbXG4gICAgQ3JlZGVudGlhbHNQcm92aWRlcih7XG4gICAgICB0eXBlOiAnY3JlZGVudGlhbHMnLFxuICAgICAgY3JlZGVudGlhbHM6IHt9LFxuICAgICAgYXV0aG9yaXplKGNyZWRlbnRpYWxzLCByZXEpIHtcbiAgICAgICAgY29uc3QgeyBlbWFpbCwgcGFzc3dvcmQgfSA9IGNyZWRlbnRpYWxzIGFzIHtcbiAgICAgICAgICBlbWFpbDogc3RyaW5nO1xuICAgICAgICAgIHBhc3N3b3JkOiBzdHJpbmc7XG4gICAgICAgIH07XG4gICAgICAgIC8vIHBlcmZvcm1pbmcgbG9naW4gbG9naWNcbiAgICAgICAgLy8gZmluZGluZyB1c2VyIGZyb20gZGJcbiAgICAgICAgaWYgKGVtYWlsID09PSAnam9obkBnbWFpbC5jb20nICYmIHBhc3N3b3JkICE9PSAnMTIzNCcpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgY3JlZGVudGlhbHMnKTtcbiAgICAgICAgfVxuICAgICAgICAvL2lmIGV2ZXJ5dGhpbmcgaXMgZmluZVxuICAgICAgICByZXR1cm4geyBpZDogJzEyMzQnLCBuYW1lOiAnam9obiBEb2UnLCBlbWFpbDogJ2pvaG5AZ21haWwuY29tJyB9O1xuICAgICAgfSxcbiAgICB9KSxcbiAgXSxcbiAgcGFnZXM6IHtcbiAgICBzaWduSW46ICcvYXV0aC9zaWduaW4nLFxuICAgIC8vIGVycm9yOiAnL2F1dGgvZXJyb3InLFxuICAgIC8vIHNpZ25PdXQ6ICcvYXV0aC9zaWdub3V0J1xuICB9LFxufTtcblxuZXhwb3J0IGRlZmF1bHQgTmV4dEF1dGgoYXV0aE9wdGlvbnMpO1xuIl0sIm5hbWVzIjpbIk5leHRBdXRoIiwiQ3JlZGVudGlhbHNQcm92aWRlciIsImF1dGhPcHRpb25zIiwic2Vzc2lvbiIsInN0cmF0ZWd5IiwicHJvdmlkZXJzIiwidHlwZSIsImNyZWRlbnRpYWxzIiwiYXV0aG9yaXplIiwicmVxIiwiZW1haWwiLCJwYXNzd29yZCIsIkVycm9yIiwiaWQiLCJuYW1lIiwicGFnZXMiLCJzaWduSW4iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/auth/[...nextauth].ts\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/auth/[...nextauth].ts"));
module.exports = __webpack_exports__;

})();